package com.example.furnituresticker;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;//TabLayout 추가

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

public class LibraryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        
        //TabLayout class 변수를 추가
        TabLayout tablayout = (TabLayout)findViewById(R.id.tabs);

        //Tab이 선택됐을 때, 각 경우별 event
        tablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            //현재 Tab과 다른 Tab이 눌렸을 경우
            public void onTabSelected(TabLayout.Tab tab) {
                int pos = tab.getPosition();
                changeView(pos) ;
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            //현재 Tab과 같은 Tab이 눌렸을 경우
            public void onTabReselected(TabLayout.Tab tab) {
                int pos = tab.getPosition();
                changeView(pos) ;
            }

        }) ;
    }

    //어떤 tab이 눌렸냐에 따라 tab에 맞는 화면을 연결
    private void changeView(int index) {
        //index가 0인경우(메인화면)
        if (index==0){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        //index가 1인경우(도움말)
        else if (index==1){
            Intent intent1 = new Intent(this, HelpActivity.class);
            startActivity(intent1);
        }
        //index가 0인경우(라이브러리)
        else if (index == 2){
            Intent intent2 = new Intent(this, LibraryActivity.class);
            startActivity(intent2);
        }
    }
}