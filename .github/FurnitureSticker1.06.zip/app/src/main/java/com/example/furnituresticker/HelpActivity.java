package com.example.furnituresticker;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;//TabLayout 추가

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;

public class HelpActivity extends AppCompatActivity {

    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button btnHelp = findViewById(R.id.btn_help);

        btnHelp.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                PopupWindow popup = new PopupWindow(v);
                LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                //팝업으로 띄울 커스텀뷰를 설정
                View view = inflater.inflate(R.layout.help_popup_window, null);
                popup.setContentView(view);
                //팝업의 크기 설정
                popup.setWindowLayoutMode(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                //팝업 뷰 터치
                popup.setTouchable(true);
                //팝업 뷰 포커스
                popup.setFocusable(true);
                //팝업 뷰 이외에도 터치 가능(터치시 팝업 닫음)
                popup.setOutsideTouchable(true);
                popup.setBackgroundDrawable(new BitmapDrawable());
                //팝업 창 위치 설정
                popup.showAtLocation(v, Gravity.CENTER, 0, 0);
            }
        });


        //TabLayout class 변수를 추가
        TabLayout tablayout = (TabLayout)findViewById(R.id.tabs);

        //Tab이 선택됐을 때, 각 경우별 event
        tablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            //현재 Tab과 다른 Tab이 눌렸을 경우
            public void onTabSelected(TabLayout.Tab tab) {
                int pos = tab.getPosition();
                changeView(pos) ;
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }
            //현재 Tab과 같은 Tab이 눌렸을 경우
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                int pos = tab.getPosition();
                changeView(pos) ;
            }

        });




    }

    //어떤 tab이 눌렸냐에 따라 tab에 맞는 화면을 연결
    private void changeView(int index) {
        //index가 0인경우(메인화면)
        if (index==0){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        //index가 1인경우(도움말)
        else if (index==1){
            Intent intent1 = new Intent(this, HelpActivity.class);
            startActivity(intent1);
        }
        //index가 0인경우(라이브러리)
        else if (index == 2){
            Intent intent2 = new Intent(this, LibraryActivity.class);
            startActivity(intent2);
        }
    }
}