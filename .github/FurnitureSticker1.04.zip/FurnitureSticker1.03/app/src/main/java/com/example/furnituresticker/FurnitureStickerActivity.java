package com.example.furnituresticker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ZoomControls;

public class FurnitureStickerActivity extends AppCompatActivity {

    ImageView imageView;

    int nBefore = 0;

    float prevX, prevY;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_furniture_sticker);
        Toolbar toolbar = findViewById(R.id.toolbar);
        TabLayout tablayout = (TabLayout)findViewById(R.id.tabs);
        tablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int pos = tab.getPosition();
                changeView(pos) ;
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                int pos = tab.getPosition();
                changeView(pos) ;
            }

        }) ;
        setSupportActionBar(toolbar);

        imageView = findViewById(R.id.FSView);

        Button zoomIn = findViewById(R.id.zoom_in);
        Button zoomOut = findViewById(R.id.zoom_out);

        Button btnLeft = findViewById(R.id.btn_left);
        Button btnRight = findViewById(R.id.btn_right);

        imageView = findViewById(R.id.FSView);


        //줌 인
        zoomIn.setOnClickListener(v -> {
            float x = imageView.getScaleX();
            float y = imageView.getScaleY();
            imageView.setScaleX((float) (x+0.1));
            imageView.setScaleY((float) (y+0.1));
        });

        //줌 아웃
        zoomOut.setOnClickListener(v -> {
            float x = imageView.getScaleX();
            float y = imageView.getScaleY();
            imageView.setScaleX((float) (x-0.1));
            imageView.setScaleY((float) (y-0.1));
        });


        btnLeft.setOnClickListener(new View.OnClickListener() {          //왼쪽 버튼 클릭(회전)
            @Override
            public void onClick(View v) {
                testRotation(nBefore - 10);
            }
        });

        btnRight.setOnClickListener(new View.OnClickListener() {          //오른쪽 버튼 클릭(회전)
            @Override
            public void onClick(View v) {
                testRotation(nBefore + 10);
            }
        });

        imageView.setOnTouchListener(new View.OnTouchListener() {
            private static final String TAG ="Drag";

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:   //뷰를 누름
                        prevX = event.getX();
                        prevY = event.getY();
                        break;
                    case MotionEvent.ACTION_MOVE:   //뷰 이동
                        float dx = event.getX() - prevX;
                        float dy = event.getY() - prevY;
                        Log.v(TAG, "dx : " + dx + " dy :: " + dy);
                        v.setX(v.getX() + dx);
                        v.setY(v.getY() + dy);
                        break;
                    case MotionEvent.ACTION_CANCEL:  //뷰 취소
                    case MotionEvent.ACTION_UP:  //뷰 가장자리 제한 설정
                        if((v.getX() < 0)){          //x축(좌,우)
                            v.setX(-prevX/5);
                        }else if((v.getX() + (prevX/2)) > prevX){
                            v.setX(prevX/2);
                        }

                        if((v.getY() < 0)){        //y축(상,하)
                            v.setY(-prevY/3);
                        }else if((v.getY() + (prevY/2)) > prevY){
                            v.setY(prevY/2);
                        }
                        break;
                }
                return true;
            }
        });
    }
    private void changeView(int index) {
        if (index==0){
                Intent intent = new Intent(this,MainActivity.class);
                startActivity(intent);
        }
        else if (index == 2){
                Intent intent2 = new Intent(this, LibraryActivity.class);
                startActivity(intent2);
        }
    }
    public void testRotation(int i){                    //회전 설정
        RotateAnimation ra = new RotateAnimation(
                nBefore,
                i,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        ra.setDuration(250);
        ra.setFillAfter(true);
        imageView.startAnimation(ra);
        nBefore = i;
    }
}